
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <script>
        $(document).ready(function () {
            $('#data').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Data Siswa</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    
<?php
$heads = [
    ['label' => 'Nama', 'width' => 30],
    ['label' => 'NIS', 'width' => 20],
    ['label' => 'Rombel', 'width' => 10],
    ['label' => 'TTL', 'width' => 20],
    ['label' => 'Status', 'width' => 15],
    ['label' => 'Aksi', 'width' => 5],

];

// $btnEdit = '<button class="btn btn-xs btn-default text-primary mx-1 shadow" title="Edit">
//                 <i class="fa fa-lg fa-fw fa-pen"></i>
//             </button>';
// $btnDelete = '<button class="btn btn-xs btn-default text-danger mx-1 shadow" title="Delete">
//                   <i class="fa fa-lg fa-fw fa-trash"></i>
//               </button>';
// $btnDetails = '<button class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
//                    <i class="fa fa-lg fa-fw fa-eye"></i>
//                </button>';

// $config = [
//     'data' => [
//         [22, 'John Bender', '+02 (123) 123456789', '<nobr>'.$btnEdit.$btnDelete.$btnDetails.'</nobr>'],
//         [19, 'Sophia Clemens', '+99 (987) 987654321', '<nobr>'.$btnEdit.$btnDelete.$btnDetails.'</nobr>'],
//         [3, 'Peter Sousa', '+69 (555) 12367345243', '<nobr>'.$btnEdit.$btnDelete.$btnDetails.'</nobr>'],
//     ],
//     'order' => [[1, 'asc']],
//     'columns' => [null, null, null, ['orderable' => false]],
// ];
?>


<?php if (isset($component)) { $__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class, ['id' => 'table1','heads' => $heads,'theme' => 'light','striped' => true,'hoverable' => true]); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['scrollable' => true]); ?>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->fullName); ?></td>
            <td><?php echo e($student->nism); ?></td>
            <td><?php echo e($student->class12); ?></td>
            <td><?php echo e($student->birthPlace); ?>, <?php echo e(\Carbon\Carbon::parse($student->birthDate)->isoFormat('DD MMM YYYY')); ?></td>
            <td></td>
            <td>
                <a href="/admin/siswa/detail/<?php echo e($student->id); ?>" class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
                       <i class="fa fa-lg fa-fw fa-eye"></i>
                </a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24)): ?>
<?php $component = $__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24; ?>
<?php unset($__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\ratakanan\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>