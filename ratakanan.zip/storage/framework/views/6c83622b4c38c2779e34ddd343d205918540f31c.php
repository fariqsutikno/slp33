
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <script>
        $(document).ready(function () {
            $('#data').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Kelengkapan Berkas</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
$heads = [
    ['label' => 'Nama', 'width' => 30],
    ['label' => 'Rombel', 'width' => 15],
    ['label' => 'Akte', 'width' => 5],
    ['label' => 'Akte Arab', 'width' => 5],
    ['label' => 'Surkes', 'width' => 5],
    ['label' => 'Surkes Arab', 'width' => 5],
    ['label' => 'Rapot', 'width' => 5],
    ['label' => 'Tazkiyah', 'width' => 5],
    ['label' => 'SKKB', 'width' => 5],
    ['label' => 'SKCK', 'width' => 5],
    ['label' => 'Foto', 'width' => 5],
    ['label' => 'Aksi', 'width' => 5],

];
// ];
?>


<?php if (isset($component)) { $__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class, ['id' => 'table1','heads' => $heads,'theme' => 'light','striped' => true,'hoverable' => true]); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['scrollable' => true]); ?>
    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($document->fullName); ?></td>
            <td><?php echo e($document->class12); ?></td>
            <td><?php if($document->akte): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->akteArab): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->surkes): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->surkesArab): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->rapor2BIM): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->tazkiyah): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->SKKB): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->SKCKArab): ?> V <?php else: ?> X <?php endif; ?></td>
            <td><?php if($document->photoWhiteBG): ?> V <?php else: ?> X <?php endif; ?></td>
            <td>
                <a href="/admin/berkas/detail/<?php echo e($document->id); ?>" class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
                       <i class="fa fa-lg fa-fw fa-eye"></i>
                </a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24)): ?>
<?php $component = $__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24; ?>
<?php unset($__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\ratakanan\resources\views/admin/berkas/index.blade.php ENDPATH**/ ?>