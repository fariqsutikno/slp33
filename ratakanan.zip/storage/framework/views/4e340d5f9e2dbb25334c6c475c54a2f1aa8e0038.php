<?php $__env->startSection('content'); ?>
    <div class="container p-5">
        <div class="row mb-3">
            <h3>Detail Siswa</h3>
        </div>
        <div class="row">
            <div class="col-md-3 my-3 mx-auto">
                <img src="https://drive.google.com/uc?export=view&id=<?php echo e($dataSiswa->photoLink); ?>" class="rounded"
                    width="180" alt="<?php echo e($dataSiswa->fullName); ?>">
                <small class="form-text text-muted text-center">Foto Ijazah - <?php echo e($dataSiswa->fullName); ?> -
                    <?php echo e($dataSiswa->class12); ?></small>
                <a href="https://drive.google.com/uc?export=download&id=<?php echo e($dataSiswa->photoLink); ?>"
                    class="btn btn-sm btn-info">Download Foto</a>
            </div>
            <div class="col-md-8 ">
                <h5>Data Siswa</h5>
                <table class="table table-sm">
                    <tr>
                        <td>Nama Lengkap</td>
                        <td><?php echo e($dataSiswa->fullName); ?></td>
                    </tr>
                    <tr>
                        <td>Nama Arab</td>
                        <td><?php echo e($dataSiswa->arabicName); ?></td>
                    </tr>
                    <tr>
                        <td>Tempat Tanggal Lahir</td>
                        <td><?php echo e($dataSiswa->birthPlace); ?>,
                            <?php echo e(date('d M Y', strtotime($dataSiswa->birthDate))); ?></td>
                    </tr>
                    <tr>
                        <td>Riwayat Kelas </td>
                        <td><span
                                class="badge mx-1 badge-info"><?php echo e($dataSiswa->class10 ? $dataSiswa->class10 : '-'); ?></span><span
                                class="badge mx-1 badge-danger"><?php echo e($dataSiswa->class11 ? $dataSiswa->class11 : '-'); ?></span><span
                                class="badge mx-1 badge-success"><?php echo e($dataSiswa->class12 ? $dataSiswa->class12 : '-'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Riwayat Kamar </td>
                        <td><?php echo e($dataSiswa->room10 ? $dataSiswa->room10 : '-'); ?>,
                            <?php echo e($dataSiswa->room11 ? $dataSiswa->room11 : '-'); ?>,
                            <?php echo e($dataSiswa->room12 ? $dataSiswa->room12 : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat Lengkap </td>
                        <td><?php echo e($dataSiswa->address? $dataSiswa->address .', ' .$dataSiswa->village .', ' .$dataSiswa->district .', ' .$dataSiswa->city .', ' .$dataSiswa->province .', ' .$dataSiswa->zipCode: '-'); ?>

                        </td>
                    </tr>
                </table>
                <h5>Nomor Identitas</h5>
                <table class="table table-sm">
                    <tr>
                        <td>NISN</td>
                        <td><?php echo e($dataSiswa->nisn); ?></td>
                    </tr>
                    <tr>
                        <td>NIS Mahad</td>
                        <td><?php echo e($dataSiswa->nism); ?></td>
                    </tr>
                    <tr>
                        <td>NIK</td>
                        <td><?php echo e($dataSiswa->nik ? $dataSiswa->nik : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>No Paspor</td>
                        <td><?php echo e($dataSiswa->noPaspor ? $dataSiswa->noPaspor : '-'); ?></td>
                    </tr>
                </table>
                <h5>Riwayat Pendidikan</h5>
                <table class="table table-sm">
                    <tr>
                        <td>SD dan Tahun Lulus</td>
                        <td><?php echo e($dataSiswa->SDName); ?> - <?php echo e($dataSiswa->SDYear); ?></td>
                    </tr>
                    <tr>
                        <td>SMP dan Tahun Lulus</td>
                        <td><?php echo e($dataSiswa->SMPName); ?> - <?php echo e($dataSiswa->SMPYear); ?></td>
                    </tr>
                </table>
                <h5>Data Orang Tua</h5>
                <table class="table table-sm">
                    <tr>
                        <td>Nama Ayah</td>
                        <td><?php echo e($dataSiswa->fatherName); ?> <span
                                class="badge badge-<?php echo e($dataSiswa->fatherStatus == 'Hidup' ? 'success' : 'danger'); ?>"><?php echo e($dataSiswa->fatherStatus); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Pekerjaan Ayah</td>
                        <td><?php echo e($dataSiswa->fatherJob ? $dataSiswa->fatherJob : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>No Telp Ayah</td>
                        <td><?php echo e($dataSiswa->fatherPhone ? $dataSiswa->fatherPhone : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Nama Ibu </td>
                        <td><?php echo e($dataSiswa->motherName); ?> <span
                                class="badge badge-<?php echo e($dataSiswa->motherStatus == 'Hidup' ? 'success' : 'danger'); ?>"><?php echo e($dataSiswa->motherStatus); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Pekerjaan Ibu </td>
                        <td><?php echo e($dataSiswa->motherJob ? $dataSiswa->motherJob : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>No Telp Ibu </td>
                        <td><?php echo e($dataSiswa->motherPhone ? $dataSiswa->motherPhone : '-'); ?></td>
                    </tr>
                </table>
                <h5>Status & Data Kelanjutan</h5>
                <table class="table table-sm">
                    <tr>
                        <td>Status Pernikahan</td>
                        <td><?php echo e($dataSiswa->maritalStatus ? $dataSiswa->maritalStatus : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Lokasi Khidmah</td>
                        <td><?php echo e($dataSiswa->khidmahPlace ? $dataSiswa->khidmahPlace : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Studi Lanjut</td>
                        <td><?php echo e($dataSiswa->furtherStudy ? $dataSiswa->furtherStudy : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Roqm Talab UIM</td>
                        <td><?php echo e($dataSiswa->roqmTalabUIM ? $dataSiswa->roqmTalabUIM : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Link Drive Berkas </td>
                        <td><a href="<?php echo e($dataSiswa->fileDriveLink); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik
                                Disini</a></td>
                    </tr>
                </table>
                <h5>Kontak</h5>
                <table class="table table-sm">
                    <tr>
                        <td>No WA </td>
                        <td><a href="https://wa.me/<?php echo e($dataSiswa->myPhone); ?>" target="_blank"><?php echo e($dataSiswa->myPhone); ?></a></td>
                    </tr>
                    <tr>
                        <td>Alamat Email Angkatan</td>
                        <!-- <td><?php echo e($dataSiswa->rkEmail); ?> <a href="https://webmail.ratakanan.org"
                                class="badge badge-info" target="_blank">Click Here to Login</a><br><small
                                class="form-text text-muted">Password : <?php echo e($dataSiswa->passwordEmail); ?></small></td>-->
                    <td><small class="form-text text-muted">Coming Soon - Belum tersedia saat ini</small></td>
                    </tr>
                    <tr>
                        <td>Alamat Email Pribadi</td>
                        <td><?php echo e($dataSiswa->myEmail ? $dataSiswa->myEmail : '-'); ?></td>
                    </tr>
                </table>
                <h5>Informasi Pendaftaran UIM</h5>
                <table class="table table-sm">
                    <tr>
                        <td>Musyrif</td>
                        <td><?php echo e($dataMadinah->musyrifName); ?> - <a href="https://wa.me/<?php echo e($dataSiswa->myPhone); ?>" target="_blank">Hubungi via Whatsapp</a></td>
                    </tr>
                    <tr>
                        <td>Status Pendaftaran</td>
                    <td><?php if($dataMadinah->selesaiDidaftarkan): ?> Selesai <?php elseif($dataMadinah->jadwalDidaftarkan): ?> Menunggu didaftarkan <?php else: ?> Menunggu Kelengkapan Data <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Jadwal Didaftarkan</td>
                        <td><?php if($dataMadinah->jadwalDidaftarkan): ?> <?php echo e(\Carbon\Carbon::parse($dataMadinah->jadwalDidaftarkan)->isoFormat('DD MM YYYY')); ?> <?php else: ?> Menunggu Kelengkapan Data <?php endif; ?></td>
                    </tr>
                </table>
                <h5>Informasi Kelengkapan Berkas UIM</h5>
                <table class="table table-sm">
                    <tr>
                        <td>Akte Asli</td>
                        <td><?php if($dataBerkas->akte): ?><a href="<?php echo e($dataBerkas->akte); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Akte Terjemah</td>
                        <td><?php if($dataBerkas->akteArab): ?><a href="<?php echo e($dataBerkas->akteArab); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Surat Kesehatan</td>
                        <td><?php if($dataBerkas->surkes): ?><a href="<?php echo e($dataBerkas->surkes); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Surat Kesehatan Terjemah</td>
                        <td><?php if($dataBerkas->surkesArab): ?><a href="<?php echo e($dataBerkas->surkesArab); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Pas Foto BG Putih</td>
                        <td><?php if($dataBerkas->photoWhiteBG): ?><a href="<?php echo e($dataBerkas->photoWhiteBG); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Rapor Kelas 2 IM</td>
                        <td><?php if($dataBerkas->rapor2BIM): ?><a href="<?php echo e($dataBerkas->rapor2BIM); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Tazkiyah</td>
                        <td><?php if($dataBerkas->tazkiyah): ?><a href="<?php echo e($dataBerkas->tazkiyah); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>SKKB</td>
                        <td><?php if($dataBerkas->SKKB): ?><a href="<?php echo e($dataBerkas->SKKB); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td>Paspor</td>
                        <td><?php if($dataBerkas->paspor): ?><a href="<?php echo e($dataBerkas->paspor); ?>" type="button" class="btn btn-sm btn-info" target="_blank">Klik Disini</a> <?php else: ?> Belum Tersedia <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <small class="text-danger">*Untuk melengkapi berkas yang masih kosong, bisa hubungi musyrif masing-masing via <a href="https://wa.me/<?php echo e($dataSiswa->myPhone); ?>">whatsapp.</a></small>
                        </td>
                    </tr>
                </table>
                <small class="text-muted">Terakhir diperbarui :
                    <?php echo e($dataSiswa->updated_at ? $dataSiswa->updated_at : '-'); ?></small>
                <div class="mt-3 float-right">
                    <form action="/edit" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="username" value="<?php echo e($dataSiswa->nism); ?>">
                        <button class="btn btn-danger">Ajukan Perubahan</button>
                        <a href="/" class="btn btn-primary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\ratakanan\resources\views/detailSiswa.blade.php ENDPATH**/ ?>