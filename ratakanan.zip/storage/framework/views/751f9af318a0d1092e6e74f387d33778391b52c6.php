
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylrkeet" href="/css/admin_custom.css">
<?php $__env->startSection('content_header'); ?>
    <h1>Detail Berkas</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="/admin/berkas/update/<?php echo e($document->id); ?>" method="POST" id="myForm" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('put')); ?>

    <div class="row mx-3">

            <h5>Identitas</h5>
            <table class="table table-sm">
                <tr>
                    <td>Nama</td>
                    <td>
                        <p title="Data tidak dapat diubah" class="d-inline"><?php echo e($document->fullName); ?></p>
                        <input type="hidden" name="fullName" value="<?php echo e($document->fullName); ?>">
                    </td>
                </tr>
                <tr>
                    <td>Kelas 12</td>
                    <td>
                        <p title="Data tidak dapat diubah" class="d-inline"><?php echo e($document->class12); ?></p>
                        <input type="hidden" name="class12" value="<?php echo e($document->class12); ?>">
                    </td>
                </tr>

            </table>
            <h5>Berkas</h5>

            <table class="table table-sm">
                <tr>
                    <td>Foto Background Putih</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->photoWhiteBG): ?>
                            <a target="_blank" href="<?php echo e($document->photoWhiteBG); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="photoWhiteBG" name="photoWhiteBG">
                            <?php $__errorArgs = ['photoWhiteBG'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>KTP</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->KTP): ?>
                            <a target="_blank" href="<?php echo e($document->KTP); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="KTP" name="KTP">
                            <?php $__errorArgs = ['KTP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Terjemahan KTP Bahasa Arab</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->KTPArab): ?>
                            <a target="_blank" href="<?php echo e($document->KTPArab); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="KTPArab" name="KTPArab">
                            <?php $__errorArgs = ['KTPArab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Akte Kelahiran</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->akte): ?>
                            <a target="_blank" href="<?php echo e($document->akte); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="akte" name="akte">
                            <?php $__errorArgs = ['akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Terjemah Akte Kelahiran Bahasa Arab</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->akteArab): ?>
                            <a target="_blank" href="<?php echo e($document->akteArab); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="akteArab" name="akteArab">
                            <?php $__errorArgs = ['akteArab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Kartu Keluarga (KK)</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->KK): ?>
                            <a target="_blank" href="<?php echo e($document->KK); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="KK" name="KK">
                            <?php $__errorArgs = ['KK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Surat Kesehatan</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->surkes): ?>
                            <a target="_blank" href="<?php echo e($document->surkes); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="surkes" name="surkes">
                            <?php $__errorArgs = ['surkes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Terjemahan Surat Kesehatan Bahasa Arab</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->surkesArab): ?>
                            <a target="_blank" href="<?php echo e($document->surkesArab); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="surkesArab" name="surkesArab">
                            <?php $__errorArgs = ['surkesArab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Surat Keterangan Kelakuan Baik (SKKB)</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->SKKB): ?>
                            <a target="_blank" href="<?php echo e($document->SKKB); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="SKKB" name="SKKB">
                            <?php $__errorArgs = ['SKKB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Surat Rekomendasi (Tazkiyah)</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->tazkiyah): ?>
                            <a target="_blank" href="<?php echo e($document->tazkiyah); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="tazkiyah" name="tazkiyah">
                            <?php $__errorArgs = ['tazkiyah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Surat Keterangan Catatan Kepolisian (SKCK)</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->SKCK): ?>
                            <a target="_blank" href="<?php echo e($document->SKCK); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="SKCK" name="SKCK">
                            <?php $__errorArgs = ['SKCK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Terjemah SKCK Bahasa Arab</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->SKCKArab): ?>
                            <a target="_blank" href="<?php echo e($document->SKCKArab); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="SKCKArab" name="SKCKArab">
                            <?php $__errorArgs = ['SKCKArab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Ijazah IM</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->ijazahIM): ?>
                            <a target="_blank" href="<?php echo e($document->ijazahIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="ijazahIM" name="ijazahIM">
                            <?php $__errorArgs = ['ijazahIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Ijazah MA</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->ijazahMA): ?>
                            <a target="_blank" href="<?php echo e($document->ijazahMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="ijazahMA" name="ijazahMA">
                            <?php $__errorArgs = ['ijazahMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Transkrip Ijazah IM</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->transkripIjazahIM): ?>
                            <a target="_blank" href="<?php echo e($document->transkripIjazahIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="transkripIjazahIM" name="transkripIjazahIM">
                            <?php $__errorArgs = ['transkripIjazahIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Transkrip Ijazah MA</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->transkripIjazahMA): ?>
                            <a target="_blank" href="<?php echo e($document->transkripIjazahMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="transkripIjazahMA" name="transkripIjazahMA">
                            <?php $__errorArgs = ['transkripIjazahMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->raporMA): ?>
                            <a target="_blank" href="<?php echo e($document->raporMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="raporMA" name="raporMA">
                            <?php $__errorArgs = ['raporMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->raporIM): ?>
                            <a target="_blank" href="<?php echo e($document->raporIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="raporIM" name="raporIM">
                            <?php $__errorArgs = ['raporIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM Kelas X Ganjil</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor1AIM): ?>
                            <a target="_blank" href="<?php echo e($document->rapor1AIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor1AIM" name="rapor1AIM">
                            <?php $__errorArgs = ['rapor1AIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM Kelas X Genap</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor1BIM): ?>
                            <a target="_blank" href="<?php echo e($document->rapor1BIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor1BIM" name="rapor1BIM">
                            <?php $__errorArgs = ['rapor1BIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM Kelas XI Ganjil</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor2AIM): ?>
                            <a target="_blank" href="<?php echo e($document->rapor2AIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor2AIM" name="rapor2AIM">
                            <?php $__errorArgs = ['rapor2AIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM Kelas XI Genap</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor2BIM): ?>
                            <a target="_blank" href="<?php echo e($document->rapor2BIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor2BIM" name="rapor2BIM">
                            <?php $__errorArgs = ['rapor2BIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM Kelas XII Ganjil</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor3AIM): ?>
                            <a target="_blank" href="<?php echo e($document->rapor3AIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor3AIM" name="rapor3AIM">
                            <?php $__errorArgs = ['rapor3AIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor IM Kelas XII Genap</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor3BIM): ?>
                            <a target="_blank" href="<?php echo e($document->rapor3BIM); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor3BIM" name="rapor3BIM">
                            <?php $__errorArgs = ['rapor3BIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA Kelas X Ganjil</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor1AMA): ?>
                            <a target="_blank" href="<?php echo e($document->rapor1AMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor1AMA" name="rapor1AMA">
                            <?php $__errorArgs = ['rapor1AMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA Kelas X Genap</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor1BMA): ?>
                            <a target="_blank" href="<?php echo e($document->rapor1BMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor1BMA" name="rapor1BMA">
                            <?php $__errorArgs = ['rapor1BMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA Kelas XI Ganjil</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor2AMA): ?>
                            <a target="_blank" href="<?php echo e($document->rapor2AMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor2AMA" name="rapor2AMA">
                            <?php $__errorArgs = ['rapor2AMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA Kelas XI Genap</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor2BMA): ?>
                            <a target="_blank" href="<?php echo e($document->rapor2BMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor2BMA" name="rapor2BMA">
                            <?php $__errorArgs = ['rapor2BMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA Kelas XII Ganjil</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor3AMA): ?>
                            <a target="_blank" href="<?php echo e($document->rapor3AMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor3AMA" name="rapor3AMA">
                            <?php $__errorArgs = ['rapor3AMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td>Rapor MA Kelas XII Genap</td>
                    <td>
                        <div class="form-group">
                            <?php if($document->rapor3BMA): ?>
                            <a target="_blank" href="<?php echo e($document->rapor3BMA); ?>" class="btn btn-outline-secondary btn-sm" type="button"><i class="fa fa-lg fa-fw fa-eye"></i> Lihat Berkas</a>
                            <small class="text-muted">atau ganti dengan dokumen baru</small><br>
                            <?php endif; ?>
                            <input type="text" class="form-control mt-2" placeholder="Isi link berkas tsb!" id="rapor3BMA" name="rapor3BMA">
                            <?php $__errorArgs = ['rapor3BMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </td>
                </tr>
            </table>
            <div class="mt-4 float-right">
                <a href="/admin/berkas" class="btn btn-secondary">Cancel</a>
                <button class="btn btn-primary show_confirm" type="submit">Submit</button>
            </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\ratakanan\resources\views/admin/berkas/detail.blade.php ENDPATH**/ ?>