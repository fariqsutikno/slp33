
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylrkeet" href="/css/admin_custom.css">
<?php $__env->startSection('content_header'); ?>
    <h1>Tambah Peserta</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="/admin/daftarUIM/store" method="POST" id="myForm">
    <?php echo csrf_field(); ?>
    <div class="row mx-3">
            <h5>Berkas</h5>
            <table class="table table-sm">
                <tr>
                    <td>Nama Siswa</td>
                    <td>
                        <div class="input-group">
                            
                            <?php if (isset($component)) { $__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class, ['name' => 'student']); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                <option value="" selected disabled>--</option>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($student->id); ?>"><?php echo e($student->fullName); ?> - <?php echo e($student->class12); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435)): ?>
<?php $component = $__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435; ?>
<?php unset($__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435); ?>
<?php endif; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Nama Musyrif</td>
                    <td>
                        <div class="input-group">
                            
                            <?php if (isset($component)) { $__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class, ['name' => 'musyrif']); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                <option value="" selected disabled>--</option>
                                <?php $__currentLoopData = $musyrifin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musyrif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($musyrif->id); ?>">Ust. <?php echo e($musyrif->musyrifName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435)): ?>
<?php $component = $__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435; ?>
<?php unset($__componentOriginal53d96464c02914da1a5e3f6d78f2486c25523435); ?>
<?php endif; ?>
                        </div>
                    </td>
                </tr>
            </table>
            <div class="mt-4 float-right">
                <a href="/" class="btn btn-secondary">Cancel</a>
                <button class="btn btn-primary show_confirm" type="submit">Submit</button>
            </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\ratakanan\resources\views/admin/daftarUIM/create.blade.php ENDPATH**/ ?>